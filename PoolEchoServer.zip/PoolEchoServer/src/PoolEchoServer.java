import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.io.*;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.PasswordAuthentication;
import javax.annotation.processing.RoundEnvironment;

import java.util.Properties;
public class PoolEchoServer extends Thread
{ 
    public final static int defaultPort = 9999; ServerSocket theServer;
    static int num_threads = 10;
    public static void main(String[] args)
    {
        int port = defaultPort;
    
        try
        { 
            port = Integer.parseInt(args[0]); 
        }
        catch (Exception e) { }
        
        if (port <= 1024|| port >= 65536) port = defaultPort;
        try {
            ServerSocket ss = new ServerSocket(port); 
            System.out.println("Server Socket Start!!"); 
            for (int i = 0; i < num_threads; i++) 
            {
                System.out.println("Create num_threads " + i + " Port:" + port); 
                PoolEchoServer pes = new PoolEchoServer(ss);
                pes.start();
            }
            }
        catch (IOException e) { System.err.println(e); }
        }
    public PoolEchoServer(ServerSocket ss) { theServer = ss; }
    public void run() { while (true) {
        try {
                DataOutputStream output;
                DataInputStream input;
                Socket connection = theServer.accept(); 
                System.out.println("Accept Client!"); //OutputStream os = s.getOutputStream(); //InputStream is = s.getInputStream(); 
                input = new DataInputStream(connection.getInputStream() );
                output = new DataOutputStream(connection.getOutputStream() );
                System.out.println("Client Connected and Start get I/O!!"); 
                while (true)
                {
                	
                	String hello = input.readUTF();
                    System.out.println("==> Input from Client: " + hello); 
                    System.out.println("Output to Client ==> \"Connection successful\""); 
  
                    output.writeUTF( "Connection successful" );

                 
                    sendData(hello);  


                } // end while
        } // end try
        catch (IOException e) { } catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    } // end while
} // end run 
    public void sendData(String data) throws InstantiationException, SQLException
    {
        Map dataMap = new HashMap();
        String textStr[] = data.split("\\s+");
        for(int i=0;i<textStr.length;i++)
        {
        	
        	System.out.println(textStr[i]);
        	
        }
        for(int i=0;i<textStr.length;i++)
        {
        	System.out.println("--->inside for");
            System.out.println(textStr[i]);
            String value[] = textStr[i].split(":");

            dataMap.put(value[0].trim(),value[1].trim()); //storing pid and value x and value etc
            
        }

        double riskClass=calculateRisk(dataMap);
        int pid=Integer.parseInt((String) dataMap.get("pid"));
        
        System.out.println("----------RiskClass-------->"+riskClass);
        sendEmail(pid, "rajendran10904@mail.npu.edu", riskClass);
        sendEmail(pid,"6086280542@txt.att.net", riskClass);
        sendDataToDB(dataMap);
    }
    public static void sendEmail(int pid,String to, double riskClass)
    {

        //Get the session object
          Properties props = new Properties();
          props.put("mail.smtp.host", "smtp.gmail.com");
          props.put("mail.smtp.socketFactory.port", "465");
          props.put("mail.smtp.socketFactory.class",
                    "javax.net.ssl.SSLSocketFactory");
          props.put("mail.smtp.auth", "true");
          props.put("mail.smtp.port", "465");
         
          Session session = Session.getDefaultInstance(props,
           new javax.mail.Authenticator() {
           protected PasswordAuthentication getPasswordAuthentication() {
           return new PasswordAuthentication("fallarmspring2015@gmail.com","2015springfallarm");
           }
          });
         
        //compose message
          try {
           MimeMessage message = new MimeMessage(session);
           message.setFrom(new InternetAddress("fallarmspring2015@gmail.com"));
           message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
           message.setSubject("Emergency Fall Alert");

           message.setText("This patient is in risk: "+pid +
        		   ". Risk factor for this patient is: "+ riskClass);
           
           //send message
           Transport.send(message);

           System.out.println("Message sent successfully");
         
          } catch (MessagingException e) {throw new RuntimeException(e);}
         
    }
    private double calculateRisk(Map dataMap ) throws NumberFormatException {
		// TODO Auto-generated method stub
    	

    	double riskclass = 0;

    	double AccX = 0.0;
    	double AccY=0.0;
    	double AccZ=0.0;
    	try{
    		AccX=Double.parseDouble((String) dataMap.get("XAcc"));

    	}
    	catch(NumberFormatException e){
    		System.out.println("----Exception");
    	}
    	catch(NullPointerException e){
    		System.out.println("----Null Exception");
    	}
    	try{
    		AccY=Double.parseDouble((String) dataMap.get("YAcc"));
    	}
    	catch(NumberFormatException e){
    		System.out.println("----Exception");
    	}
    	catch(NullPointerException e){
    		System.out.println("----Null Exception");
    	}
    	try{
    		AccZ=Double.parseDouble((String) dataMap.get("ZAcc"));
    	}
    	catch(NumberFormatException e){
    		System.out.println("----Exception");
    	}
    	catch(NullPointerException e){
    		System.out.println("----Null Exception");
    	}
    	

    	System.out.println("XAcc--->"+dataMap.get("XAcc"));
    	System.out.println("YAcc--->"+dataMap.get("YAcc"));
    	System.out.println("ZAcc--->"+dataMap.get("ZAcc"));
    	double powAccX;
    	double powAccY;
    	double powAccZ;

    	powAccX=AccX*AccX;
    	powAccY=AccY*AccY;
    	powAccZ=AccZ*AccZ;
    	try{
    	riskclass=Math.round(powAccX+powAccY+powAccZ);
    	}
    	catch (Exception e){
    		System.out.println("--");
    	}
    	
    	return riskclass;
    	
		
	}
	public void sendDataToDB(Map datamap) throws InstantiationException, SQLException{
    	
    	Connection dbConn=getDbConnection();
	
		 try{
				
			 String updateStr = "UPDATE FallArmDatabase.patient " +

							"SET AccX='"+datamap.get("XAcc")+"', AccY= '"+datamap.get("YAcc")+"', AccZ= '"+datamap.get("ZAcc")+"',"
						+ " GyroX= '"+datamap.get("XOri")+"', GyroY='"+datamap.get("YOri")+"', GyroZ='"+
						datamap.get("ZOri")+"', latitude= '"+datamap.get("Lat")+ 
							 "', longitude='"+datamap.get("Long")+ "'"+" WHERE patientid='"+datamap.get("pid")+"'";
											
					
					System.out.println(updateStr);
							Statement queryStmt = dbConn.createStatement();				
							// Free resources
							queryStmt.executeUpdate(updateStr);
							dbConn.commit();				
							queryStmt.close();
					        dbConn.close();
				} catch (SQLException ex) {
				System.out.println(ex);
				}
    	
    }
    
    private static  Connection getDbConnection() throws InstantiationException, SQLException{
	
    	String dbSourceUrl = "jdbc:mysql://localhost/FallArmDatabase?autoReconnect=true&relaxAutoCommit=true";
		Connection dbConn = null;
		 String userId = "fallarmdb_user";
		 String dbPassword = "pswdForFallArmDatabase";
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (dbConn == null) {
			dbConn = DriverManager.getConnection(dbSourceUrl, userId, dbPassword);
		}
		
		return dbConn;
		
	}
}