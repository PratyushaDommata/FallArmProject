package com.example.helloandroid;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;



import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HelloAndroid extends Activity implements SensorEventListener {
	private static final long MIN_TIME_BW_UPDATES = 200;

	private static final float MIN_DISTANCE_CHANGE_FOR_UPDATES = 1;

	private SensorManager sensorManager;
	
	private SensorManager sensorManager1;

	
	private SensorManager sensorManager2;
	
	private volatile boolean keepSend = false;
	TextView xCoor; // declare X axis object
	TextView yCoor; // declare Y axis object
	TextView zCoor; // declare Z axis object
	TextView xCoor1; // declare X axis object
	TextView yCoor1; // declare Y axis object
	TextView zCoor1; // declare Z axis object
	TextView xCoor2; // declare X axis object
	TextView yCoor2; // declare Y axis object
	TextView textIn; // Message from server
	String latLongString;
	LocationManager locationManager;
	Boolean canGetLocation;
	  Button buttonSend;
	  Button keepSendingBtn;
	@Override
	public void onCreate(Bundle savedInstanceState){

		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		xCoor=(TextView)findViewById(R.id.xcoor); // create X axis object
		yCoor=(TextView)findViewById(R.id.ycoor); // create Y axis object
		zCoor=(TextView)findViewById(R.id.zcoor); // create Z axis object
		
		xCoor1=(TextView)findViewById(R.id.xcoor1); // create X axis object
		yCoor1=(TextView)findViewById(R.id.ycoor1); // create Y axis object
		zCoor1=(TextView)findViewById(R.id.zcoor1); // create Z axis object
		
		xCoor2=(TextView)findViewById(R.id.xcoor2); // create X axis object
		yCoor2=(TextView)findViewById(R.id.ycoor2); // create Y axis object
		

		sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
		// add listener. The listener will be HelloAndroid (this) class
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
				SensorManager.SENSOR_DELAY_NORMAL);
		
		sensorManager1=(SensorManager)getSystemService(SENSOR_SERVICE);
		sensorManager1.registerListener(this,
				sensorManager1.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_NORMAL);


	/*	sensorManager2=(SensorManager)getSystemService(SENSOR_SERVICE);
		sensorManager2.registerListener(this,
				sensorManager2.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
				SensorManager.SENSOR_DELAY_NORMAL);
		/*	More sensor speeds (taken from api docs)
		    SENSOR_DELAY_FASTEST get sensor data as fast as possible
		    SENSOR_DELAY_GAME	rate suitable for games
		 	SENSOR_DELAY_NORMAL	rate (default) suitable for screen orientation changes
		*/
		
		   buttonSend = (Button)findViewById(R.id.send);
		   keepSendingBtn =(Button)findViewById(R.id.keepSending);
		     textIn = (TextView)findViewById(R.id.textin);
		     buttonSend.setOnClickListener(buttonSendOnClickListener);
		     keepSendingBtn.setOnClickListener(keepSendingListner);
		     // Adding the below code since I got an network error
		     if (android.os.Build.VERSION.SDK_INT > 9) {
		    	   StrictMode.ThreadPolicy policy = 
		    	       new StrictMode.ThreadPolicy.Builder().permitAll().build();
		    	   StrictMode.setThreadPolicy(policy);
		    	}
		    
		     LocationManager locationManager;
		     String context = Context.LOCATION_SERVICE;
		     locationManager = (LocationManager)getSystemService(context);

		     // Find the best Location Provider
		     Criteria criteria = new Criteria();
		     criteria.setAccuracy(Criteria.ACCURACY_FINE);
		     criteria.setAltitudeRequired(false);
		     criteria.setBearingRequired(false);
		     criteria.setCostAllowed(true);
		     criteria.setPowerRequirement(Criteria.POWER_LOW);
		     String provider = locationManager.getBestProvider(criteria, true);

		     Location location = locationManager.getLastKnownLocation(provider);
		     updateWithNewLocation(location);

		     // Updates are restricted to one every two seconds, 
		     // and only when movement of more than 10 meters has been detected.
		     locationManager.requestLocationUpdates(provider, 2000, 10,
		                                            locationListener);
	}
	
	private final LocationListener locationListener = new LocationListener() {
	    public void onLocationChanged(Location location) {
	      updateWithNewLocation(location);
	    }

	    public void onProviderDisabled(String provider){
	      updateWithNewLocation(null);
	    }

	    public void onProviderEnabled(String provider){ }
	    public void onStatusChanged(String provider, int status,
	                                Bundle extras){ }
	  };

	public void onAccuracyChanged(Sensor sensor, int accuracy){
		System.out.println("");
	}
	
	public void onSensorChanged(SensorEvent event){

		 boolean orChanged = false;
		 boolean acChanged = false;
		// check sensor type
		if(event.sensor.getType()==Sensor.TYPE_ACCELEROMETER){
		
			// assign directions
			float x=event.values[0];
			float y=event.values[1];
			float z=event.values[2];
			 if(!("X: "+String.valueOf(event.values[0])).equals(xCoor.getText()) || !("Y: "+String.valueOf(event.values[1])).equals(yCoor.getText()) || 
				        !("Z: "+String.valueOf(event.values[2])).equals(zCoor.getText())) {
			        	 acChanged = true;
			         }
			//System.out.println("Values = "+x+" "+y);
			xCoor.setText("XAcc:"+x);
			yCoor.setText("YAcc:"+y);
			zCoor.setText("ZAcc:"+z);
		}
		
		// check sensor type
				if(event.sensor.getType()==Sensor.TYPE_ORIENTATION){

					// assign directions
					float x=event.values[0];
					float y=event.values[1];
					float z=event.values[2];
					//System.out.println("Values = "+x+" "+y);
					  if(!("X: "+String.valueOf(event.values[0])).equals(xCoor1.getText()) || !("Y: "+String.valueOf(event.values[1])).equals(yCoor1.getText()) || 
						        !("Z: "+String.valueOf(event.values[2])).equals(zCoor1.getText())) {
					        	 orChanged = true;
					         }
					xCoor1.setText("XOri:"+x);
					yCoor1.setText("YOri:"+y);
					zCoor1.setText("ZOri:"+z);
				}
				
				// check sensor type
			/*	if(event.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD){

					// assign directions
					float x=event.values[0];
					float y=event.values[1];
					  if(!("X: "+String.valueOf(event.values[0])).equals(xCoor2.getText()) || !("Y: "+String.valueOf(event.values[1])).equals(yCoor2.getText())) {
					        	 orChanged = true;
					         }
					//System.out.println("Values = "+x+" "+y);
					xCoor2.setText("Latitude: "+x);
					yCoor2.setText("Longitude: "+y);
					
				}
				
				 */ 
			      if(keepSend == true && (acChanged == true || orChanged == true)) {
			         buttonClick();
			      }
	}
	

	 Button.OnClickListener buttonSendOnClickListener
	 = new Button.OnClickListener(){

	public void onClick(View arg0) {
	 // TODO Auto-generated method stub
		buttonClick();
	}};

	Button.OnClickListener keepSendingListner = new Button.OnClickListener() {

		public void onClick(View arg0) {
			if(buttonSend.isEnabled() == false) {
				keepSendingBtn.setText("Start keep sending all values to server when the value of one of them is changed");
				keepSend = false;
				buttonSend.setEnabled(true);
			} else {
			
			buttonSend.setEnabled(false);
			keepSendingBtn.setText("Stop keep sending all values to server when the value of one of them is changed");
			keepSend = true;
			}
		}
			
	};
	
	
	private void buttonClick() {
		Socket socket = null;
		 DataOutputStream dataOutputStream = null;
		 DataInputStream dataInputStream = null;

		 try {
		  //socket = new Socket("10.0.2.2", 4444);
        socket = new Socket("172.19.5.170", 9999);
		  dataOutputStream = new DataOutputStream(socket.getOutputStream());
		  dataInputStream = new DataInputStream(socket.getInputStream());
		  String output_message= "pid:1234"+" "+xCoor.getText().toString()+" "+yCoor.getText().toString()+" "+zCoor.getText().toString()+" "+xCoor1.getText().toString()+" "+yCoor1.getText().toString()+" "+zCoor1.getText().toString()+" "+latLongString;
		  dataOutputStream.writeUTF(output_message);
		  textIn.setText(dataInputStream.readUTF());
		 } catch (UnknownHostException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
		 } catch (IOException e) {
		  // TODO Auto-generated catch block
		  e.printStackTrace();
		 }
		 finally{
		  if (socket != null){
		   try {
		    socket.close();
		   } catch (IOException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		   }
		  }

		  if (dataOutputStream != null){
		   try {
		    dataOutputStream.close();
		   } catch (IOException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		   }
		  }

		  if (dataInputStream != null){
		   try {
		    dataInputStream.close();
		   } catch (IOException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		   }
		  }
		 }
	
	}
	private void updateWithNewLocation(Location location) {
		 
		   TextView myLocationText;
		   myLocationText = (TextView)findViewById(R.id.myLocationText);
		   if (location != null) {
		      double lat = location.getLatitude();
		      double lng = location.getLongitude();
		      latLongString = "Lat:" + lat + "\nLong:" + lng;
		   } else {
		      latLongString = "No location found";
		   }
		   myLocationText.setText("Your Current Position is:\n" +
		   latLongString);
		}
	

	
}