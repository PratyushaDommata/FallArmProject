package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.FallArmDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;
import java.sql.PreparedStatement;

public class AddNewUser {
	/* This method is used to insert a new user */
	public static void insertUser(Registration registration)
			throws SQLException, NamingException {
		Connection dbConn;
		Login newLogin;

		String queryStr = "INSERT INTO FallArmDatabase.registration(firstname,lastname,emailid,password,phonenumber,Type)"
				+ "VALUES(?,?,?,?,?,?);";
		dbConn = FallArmDb.getConnection();
		dbConn.setAutoCommit(false);
		try (PreparedStatement queryStmt = dbConn.prepareStatement(queryStr)) {
			newLogin = registration.getLogin();
			queryStmt.setString(1, registration.getFirstname());
			queryStmt.setString(2, registration.getLastname());
			queryStmt.setString(3, newLogin.getEmailid());
			queryStmt.setString(4, newLogin.getPassword());
			queryStmt.setLong(5, registration.getPhonenumber());
			queryStmt.setString(6, registration.getType());
			
			int result = queryStmt.executeUpdate();

			if (result != 1) {
				dbConn.rollback();
			}
			// Free resources
			else
				dbConn.commit();

			queryStmt.close();

		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
