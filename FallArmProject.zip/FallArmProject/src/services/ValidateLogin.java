package services;

import domainClasses.Login;
import database.FallArmDb;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.naming.NamingException;

public class ValidateLogin {
	/*
	 * This method is used to validate login name and password.
	 * returns a true value if the name and password is correct otherwise false
	 */
	public static boolean ValidateUserLogin(Login login) throws SQLException,
			NamingException {

		Connection dbConn = null;
		Statement queryStmt = null;
		ResultSet results = null;
		String emailid = login.getEmailid();
		String password = login.getPassword();

		String queryStr = "SELECT regid FROM `FallArmDatabase`.`registration` WHERE emailid = '"
				+ emailid + "' AND password = '" + password + "'";

		int customer_id = 0;

		try {
			dbConn = FallArmDb.getConnection();
			queryStmt = dbConn.createStatement();
			results = queryStmt.executeQuery(queryStr);
			if (results.next()) { // process results

				customer_id = results.getInt(1);
			} else {
				customer_id = 0;
			}
		} catch (SQLException ex) {

		} finally {
			try {

				if (results != null && !results.isClosed())
					results.close();
				if (queryStmt != null && !queryStmt.isClosed())
					queryStmt.close();

			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}

		if (customer_id == 0) {
			return false;
		} else {
			return true;
		}

	}
}
