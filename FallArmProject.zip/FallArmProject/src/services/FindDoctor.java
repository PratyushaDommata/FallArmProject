package services;


import domainClasses.Login;
import domainClasses.Patient;
import domainClasses.Registration;
import database.FallArmDb;
import domainClasses.Doctor;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.NamingException;

import java.sql.PreparedStatement;
import java.util.ArrayList;

public class FindDoctor {
	public static ArrayList<Doctor> searchDoctor(String spl) throws SQLException,
	NamingException {

Connection dbConn = null;
Statement queryStmt = null;
ResultSet results = null;

String queryStr = "Select docid,firstname,lastname,emailid,phonenumber,"
		+ "city,state,zipcode,speciality from `FallArmDatabase`.`doctor` where speciality='"+ spl+"';";


int docid;
 String firstname;
 String lastname;
 String emailid;
 long phonenumber;
 String city;
 String state;
 int zipcode;
 String speciality;
 

 Doctor doc = null;
 ArrayList<Doctor> docList = new ArrayList<Doctor>();

try {

	dbConn = FallArmDb.getConnection();
	queryStmt = dbConn.createStatement();
	results = queryStmt.executeQuery(queryStr);
	while (results.next()) { // process results
		docid = results.getInt("docid");
		firstname = results.getString("firstname");
		lastname = results.getString("lastname");
		emailid = results.getString("emailid");
		phonenumber = results.getLong("phonenumber");
		city = results.getString("city");
		state = results.getString("state");
		zipcode = results.getInt("zipcode");
		speciality = results.getString("speciality");
		
		doc = new Doctor(docid,firstname,lastname,phonenumber,emailid,city,
				state,zipcode,speciality);
		docList.add(doc);

	}
} 
catch (SQLException ex) {

} finally {
	try {

		if (results != null && !results.isClosed())
			results.close();
		if (queryStmt != null && !queryStmt.isClosed())
			queryStmt.close();

	} catch (SQLException ex) {
		ex.printStackTrace();
	}
}

// Free resources
return docList;

}
}
