package services;

import domainClasses.Login;
import domainClasses.Registration;
import database.FallArmDb;
import domainClasses.Patient;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.NamingException;

import java.sql.PreparedStatement;
import java.util.ArrayList;

public class GetAllPatientDetails {
	public static ArrayList<Patient> allPatientDetails() throws SQLException,
	NamingException {

Connection dbConn = null;
Statement queryStmt = null;
ResultSet results = null;

String queryStr = "Select patientid,firstname,lastname,emailid,phonenumber,"
		+ "city,state,zipcode,deviceid,AccX,AccY,AccZ,GyroX,GyroY,GyroZ,"
		+ "latitude,longitude from `FallArmDatabase`.`patient` ";
 int patientid;
 String firstname;
 String lastname;
 String emailid;
 long phonenumber;
 String city;
 String state;
 int zipcode;
 int deviceid;
 double accX;
 double accY;
 double accZ;
 double gyroX;
 double gyroY;
 double gyroZ;
 double latitude;
 double longitude;

 Patient patient = null;
 ArrayList<Patient> detailsList = new ArrayList<Patient>();

try {

	dbConn = FallArmDb.getConnection();
	queryStmt = dbConn.createStatement();
	results = queryStmt.executeQuery(queryStr);
	while (results.next()) { // process results
		patientid = results.getInt("patientid");
		firstname = results.getString("firstname");
		lastname = results.getString("lastname");
		emailid = results.getString("emailid");
		phonenumber = results.getLong("phonenumber");
		city = results.getString("city");
		state = results.getString("state");
		zipcode = results.getInt("zipcode");
		deviceid = results.getInt("deviceid");
		accX = results.getDouble("AccX");
		accY = results.getDouble("AccY");
		accZ = results.getDouble("AccZ");
		gyroX = results.getDouble("GyroX");
		gyroY = results.getDouble("GyroY");
		gyroZ = results.getDouble("GyroZ");
		latitude = results.getDouble("latitude");
		longitude = results.getDouble("longitude");
		
		patient = new Patient(patientid,firstname,lastname,phonenumber,emailid,city,
				state,zipcode,deviceid,accX,accY,accZ,gyroX,gyroY,gyroZ,latitude,
				longitude);
		detailsList.add(patient);

	}
} 
catch (SQLException ex) {

} finally {
	try {

		if (results != null && !results.isClosed())
			results.close();
		if (queryStmt != null && !queryStmt.isClosed())
			queryStmt.close();

	} catch (SQLException ex) {
		ex.printStackTrace();
	}
}

// Free resources
return detailsList;

}
}
