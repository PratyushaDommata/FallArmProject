package servletForms;

import javax.servlet.http.HttpServletRequest;
import domainClasses.Login;

/*Extract login data and validate*/
public class LoginValidationForm {
	private String emailid;
	private String password;
	private Login login;
	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public LoginValidationForm(HttpServletRequest request) {
		login = extractFormData(request);
	}

	public String getEmailid() {
		return emailid;
	}

	public String getPassword() {
		return password;
	}

	public Login extractFormData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		emailid = request.getParameter("emailid");
		password = request.getParameter("password");

		validationMsg = validationMsgForName(emailid);
		if (validationMsg != null) {

			request.setAttribute("errorInEmailIdMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(password);
		if (validationMsg != null) {
			request.setAttribute("errorInPasswordMsg", validationMsg);
			formDataValid = false;
		}
		if (!formDataValid) {
			return null;
		}
		login = new Login(emailid, password);
		return login;

	}

	public Login getLogin() {
		return login;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}

}
