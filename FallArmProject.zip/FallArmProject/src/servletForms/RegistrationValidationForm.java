package servletForms;

import javax.servlet.http.HttpServletRequest;

import domainClasses.Login;
import domainClasses.Registration;


/*Extract registration data and validate*/
public class RegistrationValidationForm {
	private String firstname;
	private String lastname;
	private String phonenumber;
	private String type;
	private String emailid;
	private String password;
	private Login login;
	private Registration registration;
	private final static String fieldCannotBeLeftEmptyMsg = "This field cannot be left empty";

	public RegistrationValidationForm(HttpServletRequest request) {
		login = extractLoginData(request);
		registration = extractRegistrationData(request);
	}

	public Login extractLoginData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		emailid = request.getParameter("email");
		password = request.getParameter("password");

		validationMsg = validationMsgForName(emailid);
		if (validationMsg != null) {

			request.setAttribute("errorInEmailMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(password);
		if (validationMsg != null) {
			request.setAttribute("errorInPasswordMsg", validationMsg);
			formDataValid = false;
		}
		if (!formDataValid) {
			return null;
		}
		login = new Login(emailid, password);
		return login;

	}

	public Registration extractRegistrationData(HttpServletRequest request) {
		String validationMsg;
		boolean formDataValid = true;
		login = getLogin();
		firstname = request.getParameter("fname");
		lastname = request.getParameter("lname");
		phonenumber = request.getParameter("phone");
		type = request.getParameter("type");
		
		validationMsg = validationMsgForName(firstname);
		if (validationMsg != null) {

			request.setAttribute("errorInFnameMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(lastname);
		if (validationMsg != null) {
			request.setAttribute("errorInLnameMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(phonenumber);
		if (validationMsg != null) {

			request.setAttribute("errorInPhoneMsg", validationMsg);
			formDataValid = false;
		}
		validationMsg = validationMsgForName(type);
		if (validationMsg != null) {
			request.setAttribute("errorInTypeMsg", validationMsg);
			formDataValid = false;
		}
		
		if (!formDataValid) {
			return null;
		}
		login = getLogin();
		registration = new Registration(login, firstname, lastname, 
				Long.parseLong(phonenumber),type);
		return registration;
	}

	public Login getLogin() {
		return login;
	}

	public Registration getRegistration() {
		return registration;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public String getEmailid() {
		return emailid;
	}
	
	public String getType() {
		return type;
	}

	public String getPassword() {
		return password;
	}


	public String getPhonenumber() {
		return phonenumber;
	}

	private String validationMsgForName(String name) {
		if (name.length() == 0) {
			return fieldCannotBeLeftEmptyMsg;
		}
		return null;
	}
}
