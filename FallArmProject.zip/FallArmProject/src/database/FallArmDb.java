package database;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

import com.mysql.jdbc.Statement;

public class FallArmDb {
	//private static DataSource fallarmDbDataSource = null;
    private static BasicDataSource fallarmDbDataSource = null;
    
	public static BasicDataSource initDataSource() throws NamingException {
		Context initContext;

		/*
		 * The datasource needs to be configured in Tomcat since this is a web
		 * application. NamingException is thrown if there is a failure looking
		 * up the data source. We can't handle it here.
		 */
		/*initContext = new InitialContext();
		Context envContext = (Context) initContext.lookup("java:/comp/env");
		DataSource dataSource = (DataSource) envContext
				.lookup("jdbc/FallArmDatabase");
		return dataSource;*/
		
		BasicDataSource dataSrc = new BasicDataSource();
        dataSrc.setDriverClassName("com.mysql.jdbc.Driver");
        dataSrc.setUsername("fallarmdb_user");
        dataSrc.setPassword("pswdForFallArmDatabase");
        dataSrc.setUrl("jdbc:mysql://localhost/FallArmDatabase");
        dataSrc.setMaxActive(10);
        
        return dataSrc;
	}

	public static Connection getConnection() throws NamingException,
			SQLException {
		Connection dbConn;

		if (fallarmDbDataSource == null) {
			fallarmDbDataSource = initDataSource();
		}

		dbConn = fallarmDbDataSource.getConnection();
		return dbConn;
	}

}
