package servlets;

import domainClasses.Login;
import domainClasses.Patient;
import services.ValidateLogin;
import servletForms.LoginValidationForm;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet({ "/PatientDetailsServlet" })
public class PatientDetailsServlet extends HttpServlet{
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(true);
		response.setContentType("text/html");

		try {

			int pid = Integer.parseInt(request.getParameter("patientid"));
			
			ArrayList<Patient> detailsList = new ArrayList<Patient>();
			detailsList = services.PatientDetails.patientDetails(pid);
			request.setAttribute("detailsList", detailsList);
			session.setAttribute("patient", detailsList.get(0));
			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/patientDetails.jsp");
			
			dispatch.forward(request, response);
			
			return;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
