package servlets;

import domainClasses.Registration;
import domainClasses.Login;
import services.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servletForms.*;

@WebServlet({ "/RegistrationServlet" })
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		try {
			RegistrationValidationForm validation = new RegistrationValidationForm(
					request);

			Registration registration = validation.getRegistration();

			if (registration == null) {
				request.setAttribute("validation", validation);
				ServletContext context = getServletContext();
				RequestDispatcher dispatch = context
						.getRequestDispatcher("/views/signUpPage.jsp");
				dispatch.forward(request, response);

				return;

			}

			services.AddNewUser.insertUser(registration);

			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/registrationConfirmation.jsp");
			dispatch.forward(request, response);

		} catch (SQLException e) {

			e.printStackTrace();
		} catch (NamingException e) {

			e.printStackTrace();
		}
		out.println("</body></html>");

	}

}
