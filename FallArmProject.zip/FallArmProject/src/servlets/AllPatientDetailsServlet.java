package servlets;

import domainClasses.Login;
import domainClasses.Patient;
import services.ValidateLogin;
import servletForms.LoginValidationForm;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet({ "/AllPatientDetailsServlet" })
public class AllPatientDetailsServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(true);
		response.setContentType("text/html");

		try {

			
			ArrayList<Patient> detailsList = new ArrayList<Patient>();
			detailsList = services.GetAllPatientDetails.allPatientDetails();
			request.setAttribute("detailsList", detailsList);
			//session.setAttribute("patient", detailsList.get(0));
			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/allPatientDetails.jsp");
			
			dispatch.forward(request, response);
			
			return;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

