package servlets;


import domainClasses.Login;
import domainClasses.Patient;
import domainClasses.Doctor;
import services.ValidateLogin;
import servletForms.LoginValidationForm;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/FindDoctorServlet" })
public class FindDoctorServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession session = request.getSession(false);
		response.setContentType("text/html");

		try {
			String speciality = request.getParameter("Speciality");
			//Category category = new Category(cat);
			ArrayList<Doctor> docList = new ArrayList<Doctor>();
			docList = services.FindDoctor.searchDoctor(speciality);
			request.setAttribute("docList", docList);
			ServletContext context = getServletContext();
			RequestDispatcher dispatch = context
					.getRequestDispatcher("/views/DoctorDetails.jsp");
			dispatch.forward(request, response);
			return;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
