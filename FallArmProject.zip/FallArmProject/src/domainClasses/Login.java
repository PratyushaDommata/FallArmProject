package domainClasses;

public class Login {
	String emailid;
	String password;

	public Login() {

	}

	public Login(String emailid) {
		this.emailid = emailid;

	}

	public Login(String emailid, String password) {
		this.emailid = emailid;
		this.password = password;
	}

	public String getEmailid() {
		return this.emailid;
	}

	public String getPassword() {
		return this.password;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String toString() {
		return "Login[" + emailid + " " + password + "]";
	}

}
