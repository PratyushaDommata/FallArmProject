package domainClasses;

public class Doctor {
	private int docid;
	private String firstname;
	private String lastname;
	private String emailid;
	private long phonenumber;
	private String city;
	private String state;
	private int zipcode;
	private String speciality;

	public Doctor(int docid,String firstname, String lastname, long phonenumber,
			String emailid, String city, String state, int zipcode,
			String speciality) {
		this.docid = docid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phonenumber = phonenumber;
		this.emailid = emailid;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.speciality = speciality;

	}

	public int getDocid() {
		return docid;
	}

	public String getFirstname() {
		return firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public String getEmailid() {
		return emailid;
	}

	public long getPhonenumber() {
		return phonenumber;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public int getZipcode() {
		return zipcode;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setDocid(int docid) {
		this.docid = docid;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public void setPhonenumber(long phonenumber) {
		this.phonenumber = phonenumber;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
}
