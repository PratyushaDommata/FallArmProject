package domainClasses;

public class Patient {
private int patientid;
private String firstname;
private String lastname;
private String emailid;
private long phonenumber;
private String city;
private String state;
private int zipcode;
private int deviceid;
private double accX;
private double accY;
private double accZ;
private double gyroX;
private double gyroY;
private double gyroZ;
private double latitude;
private double longitude;


public Patient(int patientid,String firstname, String lastname, long phonenumber, String emailid,
		String city, String state,int zipcode,int deviceid,double accX,double accY,
		double accZ,double gyroX,double gyroY,double gyroZ,double latitude,double longitude) {
	this.patientid=patientid;
	this.firstname = firstname;
	this.lastname = lastname;
	this.phonenumber = phonenumber;
	this.emailid = emailid;
	this.city = city;
	this.state = state;
	this.zipcode = zipcode;
	this.deviceid = deviceid;
	this.accX=accX;
	this.accY=accY;
	this.accZ=accZ;
	this.gyroX=gyroX;
	this.gyroY=gyroY;
	this.gyroZ=gyroZ;
	this.latitude=latitude;
	this.longitude=longitude;
}

public int getPatientid() {
	return patientid;
}


public String getFirstname() {
	return firstname;
}

public String getLastname() {
	return lastname;
}

public String getEmailid() {
	return emailid;
}

public long getPhonenumber() {
	return phonenumber;
}

public String getCity() {
	return city;
}

public String getState() {
	return state;
}

public int getZipcode() {
	return zipcode;
}
public int getDeviceid() {
	return deviceid;
}

public double getAccX() {
	return accX;
}
public double getAccY() {
	return accY;
}
public double getAccZ() {
	return accZ;
}
public double getGyroX() {
	return gyroX;
}
public double getGyroY() {
	return gyroY;
}
public double getGyroZ() {
	return gyroZ;
	
}
public double getLatitude() {
	return latitude;
	
}
public double getLongitude() {
	return longitude;
	
}
public void setPatientid(int patientid) {
	this.patientid = patientid;
}

public void setFirstname(String firstname) {
	this.firstname = firstname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}

public void setEmailid(String emailid) {
	this.emailid = emailid;
}

public void setPhonenumber(long phonenumber) {
	this.phonenumber = phonenumber;
}

public void setCity(String city) {
	this.city = city;
}

public void setState(String state) {
	this.state = state;
}

public void setZipcode(int zipcode) {
	this.zipcode = zipcode;
}
public void setDeviceid(int deviceid) {
	this.deviceid = deviceid;
}

public void setAccX(double accX) {
	this.accX = accX;
}

public void setAccY(double accY) {
	this.accY = accY;
}

public void setAccZ(double accZ) {
	this.accZ = accZ;
}

public void setGyroX(double gyroX) {
	this.gyroX = gyroX;
}

public void setGyroY(double gyroY) {
	this.gyroY = gyroY;
}

public void setGyroZ(double gyroZ) {
	this.gyroZ = gyroZ;
}

public void setLatitude(double latitude) {
	this.latitude = latitude;
}

public void setLongitude(double longitude) {
	this.longitude = longitude;
}


}

