package domainClasses;

public class Registration {
private Login login;
private String firstname;
private String lastname;
private long phonenumber;
private String type;

public Registration(Login login, String firstname, String lastname, long phonenumber, String type) {
	this.login=login;
	this.firstname = firstname;
	this.lastname = lastname;
	this.phonenumber = phonenumber;
	this.type = type;
}



public String getFirstname() {
	return firstname;
}

public String getLastname() {
	return lastname;
}

public long getPhonenumber() {
	return phonenumber;
}
public Login getLogin() {
	return login;
}

public String getType() {
	return type;
}

public void setFirstname(String firstname) {
	this.firstname = firstname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}
public void setPhonenumber(long phonenumber) {
	this.phonenumber = phonenumber;
}
public void setLogin(Login login) {
	this.login = login;
}

public void setType(String type) {
	this.type = type;
}
}

