package test_junit;
import com.thoughtworks.selenium.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

import java.util.regex.Pattern;

import junit.framework.TestCase;

public class SignUp_JUnit extends TestCase {
	private Selenium selenium;

	@Before
	public void setUp() throws Exception {
		selenium = new DefaultSelenium("localhost", 4444, "*chrome", "https://www.google.com/");
		selenium.start();
	}

	@Test
	public void testSignUp_JUnit() throws Exception {
		selenium.open("http://localhost:8080/FallArmProject/");
		selenium.waitForPageToLoad("10000");
		selenium.click("link=Sign-Up");
		selenium.waitForPageToLoad("10000");
		selenium.type("name=fname", "Shruti");
		//selenium.type("name=fname", "Shruti");
		selenium.type("name=lname", "R");
		//selenium.type("name=lname", "R");
		selenium.type("name=email", "shru@gmail.com");
		selenium.type("name=email", "shru@gmail.com");
		//selenium.type("name=password", "shru11");
		selenium.type("name=password", "shru11");
		//selenium.type("name=phone", "123456789");
		selenium.type("name=phone", "123456789");
		selenium.select("name=type", "label=Doctor");
		//selenium.select("name=type", "label=Doctor");
		selenium.click("css=input[type=\"submit\"]");
	}

	@After
	public void tearDown() throws Exception {
		selenium.stop();
	}
}
