package test_junit;

import junit.framework.Test;
import junit.framework.TestSuite;

public class FallarmTestSuite_JUnit {

  public static Test suite() {
    TestSuite suite = new TestSuite();
    suite.addTestSuite(Doctor_JUnit.class);
    suite.addTestSuite(Patient_JUnit.class);
    suite.addTestSuite(SignUp_JUnit.class);
    suite.addTestSuite(DBConn_Test.class);
    return suite;
  }

  public static void main(String[] args) {
    junit.textui.TestRunner.run(suite());
  }
}
