package test_junit;
import static org.junit.Assert.*;
import static org.junit.Assert.*;

import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Test;
import org.junit.After;

import java.util.ArrayList;

import database.FallArmDb;
import domainClasses.*;
import services.*;

import org.junit.Assert;
import org.junit.Test;

import java.sql.Connection;

import junit.framework.TestCase;

public class DBConn_Test extends TestCase{	
	FallArmDb db1 = new FallArmDb();
	Login login1=new Login("pratyu@gmail.com","pra@12");
	ArrayList<Patient> detailsList = new ArrayList<Patient>();	
	
	@Test
	public void testGetUserType() throws InstantiationException, NullPointerException, SQLException, NamingException {
		try {
			String type;
			type = GetUserType.GetTypeOfUser(login1);
			assertEquals(type,"Doctor");
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		
	}
	
	@Test
	public void testGetConnection() throws SQLException, InstantiationException, NamingException {
		Connection con = (Connection) FallArmDb.getConnection();
		Assert.assertNotNull(con);
		Assert.assertTrue(con.isValid(0));
		con.close();
	}
	
	@Test
	public void testgetPatientDetailsFromDB() throws InstantiationException, SQLException, NamingException { 

		detailsList= PatientDetails.patientDetails(1234);
				
		String fname=detailsList.get(0).getFirstname(); 
		String lname=detailsList.get(0).getLastname();
		assertEquals(fname,"Aparna");
		assertEquals(lname,"Mantha");
	}

	@After
	public void cleanUp() {
		db1 = null;
		login1 = null;
		detailsList = null;
	}
}