CREATE SCHEMA `FallArmDatabase` ;


CREATE TABLE `FallArmDatabase`.`registration` (
  `regid` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `phonenumber` bigint DEFAULT NULL,
  `emailid` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `Type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`regid`)
);

INSERT INTO `FallArmDatabase`.`registration`(`firstname`,`lastname`,`phonenumber`,`emailid`,`password`,`Type`) 
values('pratyusha','dommata',1234567890,'pratyu@gmail.com','pra@12','Doctor');


INSERT INTO `FallArmDatabase`.`registration`(`firstname`,`lastname`,`phonenumber`,`emailid`,`password`,`Type`) 
values('Aparna','Mantha',4567890123,'appu@gmail.com','appu@12','Patient');



CREATE TABLE `FallArmDatabase`.`patient` (
  `patientid` int NOT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `emailid` varchar(30) DEFAULT NULL,
  `phonenumber` bigint DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `zipcode` int DEFAULT NULL,
  `deviceid` int DEFAULT NULL,
  `AccX` double DEFAULT NULL,
  `AccY` double DEFAULT NULL,
  `AccZ` double DEFAULT NULL,
  `GyroX` double DEFAULT NULL,
  `GyroY` double DEFAULT NULL,
  `GyroZ` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  PRIMARY KEY (`patientid`)
);



INSERT INTO `FallArmDatabase`.`patient`(`patientid`,`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`deviceid`,`latitude`,`longitude`) 
values(1234,'Aparna','Mantha','appu@gmail.com',4567890123,'Alpha','Michigan',1234,1111,37.774928333333335,-122.419415);


CREATE TABLE `FallArmDatabase`.`doctor` (
  `docid` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) DEFAULT NULL ,
  `lastname` varchar(30) DEFAULT NULL,
  `emailid` varchar(30) DEFAULT NULL,
  `phonenumber` bigint DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `zipcode` int DEFAULT NULL,
  `speciality` varchar(30) DEFAULT NULL,
   PRIMARY KEY (`docid`)
);


INSERT INTO `FallArmDatabase`.`doctor`(`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`speciality`) 
values('Aparna','Mantha','appu@gmail.com',4567890123,'Alpha','Michigan',1234,'Dermatology');


INSERT INTO `FallArmDatabase`.`doctor`(`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`speciality`) 
values('Pratyusha','Dommata','pratyu@gmail.com',4567890123,'Fremont','California',94539,'Neurology');

INSERT INTO `FallArmDatabase`.`doctor`(`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`speciality`) 
values('Pranav','Dommata','panni@gmail.com',8901234567,'Hyderabad','Telangana',500062,'Cardiology');


INSERT INTO `FallArmDatabase`.`doctor`(`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`speciality`) 
values('Srikanth','Pagidi','sri@gmail.com',9012345678,'Campbell','California',8123,'Pediatrics');


INSERT INTO `FallArmDatabase`.`doctor`(`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`speciality`) 
values('Vani','Dommata','vani@gmail.com',9012345678,'Hyderabad','Telangana',500062,'Gynecology');


INSERT INTO `FallArmDatabase`.`doctor`(`firstname`,`lastname`,`emailid`,`phonenumber`,`city`,`state`,
`zipcode`,`speciality`) 
values('Vijaya','Pagidi','vijju@gmail.com',9012345678,'Hyderabad','Telangana',500062,'Gynecology');


