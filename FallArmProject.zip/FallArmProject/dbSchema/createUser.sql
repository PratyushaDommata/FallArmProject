
CREATE USER 'fallarmdb_user'@'localhost' IDENTIFIED BY 'pswdForFallArmDatabase';

GRANT ALL PRIVILEGES ON FallArmDatabase.* TO 'fallarmdb_user'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'fallarmdb_user'@'localhost';

